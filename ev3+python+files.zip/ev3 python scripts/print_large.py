#!/usr/bin/env Python3
from time import sleep
from os import system

system('setfont Lat15-TerminusBold32x16')

print('Hello, world!')
sleep(5)
