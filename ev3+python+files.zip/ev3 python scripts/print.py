#!/usr/bin/env python3
from time import sleep

print('Hello, world!')
sleep(5)
