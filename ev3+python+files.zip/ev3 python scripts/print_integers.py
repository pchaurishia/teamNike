#!/usr/bin/env python3
from time import sleep

for i in range (56):
    print(i)

sleep(8)
