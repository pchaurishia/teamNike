#!/usr/bin/env python3
from time import sleep

for i in range (8):
    for j in range (7):
        print(i*7+j, end=' ')
    print('') # start a new line
sleep(8)
