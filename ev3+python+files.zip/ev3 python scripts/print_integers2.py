#!/usr/bin/env python3
from time import sleep

for i in range (56):
    print(i, end=' ')
print('') # start a new line
sleep(8)
